package com.dentallab.clinic;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** حساب العيادة: المستحق والمدفوع والمتبقي (لحظي) */
public class AccountFragment extends Fragment {
    private final List<CaseItem> cases = new ArrayList<>();
    private final List<Payment> pays = new ArrayList<>();
    private final List<ListenerRegistration> regs = new ArrayList<>();
    private TextView header;
    private ListView list;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        header = v.findViewById(R.id.header);
        header.setVisibility(View.VISIBLE);
        regs.add(Repo.db().collection("cases").whereEqualTo("clinicId", Repo.uid()).addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            cases.clear(); cases.addAll(snap.toObjects(CaseItem.class)); render();
        }));
        regs.add(Repo.db().collection("payments").whereEqualTo("clinicId", Repo.uid()).addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            pays.clear(); pays.addAll(snap.toObjects(Payment.class)); render();
        }));
        return v;
    }

    private void render() {
        double due = 0, paid = 0;
        List<Object[]> items = new ArrayList<>();
        for (CaseItem k : cases) {
            if (k.price <= 0) continue;
            due += k.price;
            items.add(new Object[]{k.createdAt, new CardAdapter.Row(Ui.caseTitle(requireContext(), k, false),
                    Ui.money(k.price), Ui.statusLabel(requireContext(), k.status), Ui.statusColor(k.status))});
        }
        for (Payment p : pays) {
            paid += p.amount;
            items.add(new Object[]{p.createdAt, new CardAdapter.Row("\uD83D\uDCB5 " + Ui.money(p.amount),
                    Ui.nz(p.note), getString(R.string.acc_payment), 0xFF2E7D32)});
        }
        Collections.sort(items, (a, b) -> Long.compare((Long) b[0], (Long) a[0]));
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (Object[] it : items) rows.add((CardAdapter.Row) it[1]);
        header.setText(getString(R.string.acc_summary, Ui.money(due), Ui.money(paid), Ui.money(due - paid)));
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    @Override public void onDestroyView() {
        for (ListenerRegistration r : regs) r.remove();
        regs.clear();
        super.onDestroyView();
    }
}
