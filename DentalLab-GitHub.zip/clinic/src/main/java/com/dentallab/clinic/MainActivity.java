package com.dentallab.clinic;
import android.content.Intent;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;

public class MainActivity extends BaseMainActivity {
    @Override public boolean isLab() { return false; }
    @Override protected int menuRes() { return R.menu.bottom_nav; }
    @Override protected int firstItemId() { return R.id.nav_cases; }
    @Override protected boolean fabVisibleFor(int id) { return id == R.id.nav_cases; }
    @Override protected void onFabClick() { startActivity(new Intent(this, NewCaseActivity.class)); }

    @Override protected Fragment fragmentFor(int id) {
        if (id == R.id.nav_cases) return new CasesFragment();
        if (id == R.id.nav_appts) return new AppointmentsFragment();
        if (id == R.id.nav_account) return new AccountFragment();
        return new MoreFragment();
    }
}
