# نماذج Firestore تُقرأ بالانعكاس (reflection) فلا يجوز تصغيرها
-keep class com.dentallab.core.CaseItem { *; }
-keep class com.dentallab.core.CaseFile { *; }
-keep class com.dentallab.core.Appointment { *; }
-keep class com.dentallab.core.Payment { *; }
-keep class com.dentallab.core.UserProfile { *; }
-keep class com.dentallab.core.InventoryItem { *; }
-keepattributes Signature,*Annotation*
