package com.dentallab.core;
import android.app.Activity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.os.LocaleListCompat;

/** تغيير لغة التطبيق (يُحفظ تلقائياً) */
public class Lang {
    private static final String[] TAGS = {"", "ar", "en"};
    private static final String[] NAMES = {null, "العربية", "English"};

    public static void showDialog(Activity a) {
        String[] items = NAMES.clone();
        items[0] = a.getString(R.string.lang_system);
        String cur = AppCompatDelegate.getApplicationLocales().toLanguageTags();
        int checked = 0;
        for (int i = 1; i < TAGS.length; i++) if (cur.startsWith(TAGS[i])) checked = i;
        new AlertDialog.Builder(a).setTitle(R.string.more_language)
                .setSingleChoiceItems(items, checked, (d, w) -> {
                    AppCompatDelegate.setApplicationLocales(w == 0 ? LocaleListCompat.getEmptyLocaleList()
                            : LocaleListCompat.forLanguageTags(TAGS[w]));
                    d.dismiss();
                })
                .setNegativeButton(R.string.btn_cancel, null).show();
    }
}
