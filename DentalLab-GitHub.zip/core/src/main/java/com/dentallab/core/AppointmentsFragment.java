package com.dentallab.core;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** المواعيد: العيادة تحجز، والمعمل يؤكد أو يرفض (اضغط على الموعد). اضغط مطولاً للحذف. */
public class AppointmentsFragment extends Fragment {
    private boolean lab;
    private ListView list;
    private ListenerRegistration reg;
    private List<Appointment> data = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        lab = ((Host) requireActivity()).isLab();
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        FloatingActionButton fab = v.findViewById(R.id.fab);
        fab.setVisibility(lab ? View.GONE : View.VISIBLE);
        fab.setOnClickListener(x -> add());
        list.setOnItemClickListener((p, view, pos, id) -> {
            if (!lab) return;
            Appointment a = data.get(pos);
            String[] labels = {getString(R.string.ap_pending), getString(R.string.ap_confirmed), getString(R.string.ap_rejected)};
            new AlertDialog.Builder(requireContext()).setTitle(R.string.title_appt_status)
                    .setItems(labels, (d, w) -> Repo.db().collection("appointments").document(a.id).update("status", w)).show();
        });
        list.setOnItemLongClickListener((p, view, pos, id) -> {
            Appointment a = data.get(pos);
            Ui.confirm(requireContext(), R.string.confirm_delete, () -> Repo.db().collection("appointments").document(a.id).delete());
            return true;
        });

        Query q = Repo.db().collection("appointments");
        if (!lab) q = q.whereEqualTo("clinicId", Repo.uid());
        reg = q.addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            data = snap.toObjects(Appointment.class);
            Collections.sort(data, (a, b) -> Long.compare(b.createdAt, a.createdAt));
            List<CardAdapter.Row> rows = new ArrayList<>();
            for (Appointment a : data) {
                String ref = Ui.nz(a.patientRef).trim();
                String sub = (lab ? "\uD83D\uDC68\u200D\u2695\uFE0F " + Ui.nz(a.clinicName) + (ref.isEmpty() ? "" : "\n") : "") + ref;
                rows.add(new CardAdapter.Row("\uD83D\uDCC5 " + a.date + "   \u23F0 " + a.time, sub,
                        Ui.apptLabel(requireContext(), a.status), Ui.apptColor(a.status)));
            }
            list.setAdapter(new CardAdapter(requireContext(), rows));
        });
        return v;
    }

    private void add() {
        Ui.form(requireContext(), R.string.title_new_appt, new int[]{R.string.hint_patient_opt}, f ->
            Ui.pickDate(requireContext(), date -> Ui.pickTime(requireContext(), time -> {
                Appointment a = new Appointment();
                a.clinicId = Repo.uid();
                a.clinicName = Profile.name(requireContext());
                a.clinicPhone = Profile.e164(requireContext());
                a.patientRef = f[0]; a.date = date; a.time = time;
                a.status = 0; a.createdAt = System.currentTimeMillis();
                Repo.db().collection("appointments").add(a);
            })));
    }

    @Override public void onDestroyView() {
        if (reg != null) reg.remove();
        super.onDestroyView();
    }
}
