package com.dentallab.core;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/** مخطط الأسنان بالصورة الحقيقية للفكين (ترقيم FDI). اضغط على السن لتحديده. */
public class TeethChartView extends View {
    public interface Listener { void onChanged(String csv); }

    private final Map<Integer, Path> paths = new LinkedHashMap<>();
    private final Map<Integer, float[]> polys = new LinkedHashMap<>();
    private final Map<Integer, float[]> centers = new LinkedHashMap<>();
    private final Set<Integer> selected = new TreeSet<>();
    private Bitmap bmp;
    private boolean readOnly;
    private Listener listener;
    private float scale = 1f;
    private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
    private final Paint fillSel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokeSel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TeethChartView(Context c) { super(c); init(); }
    public TeethChartView(Context c, AttributeSet a) { super(c, a); init(); }

    private void init() {
        fillSel.setStyle(Paint.Style.FILL);
        fillSel.setColor(0xB000796B);
        strokeSel.setStyle(Paint.Style.STROKE);
        strokeSel.setStrokeWidth(4f);
        strokeSel.setColor(0xFF004D40);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        textPaint.setTextSize(28f);
        halo.setTextAlign(Paint.Align.CENTER);
        halo.setFakeBoldText(true);
        halo.setTextSize(28f);
        halo.setStyle(Paint.Style.STROKE);
        halo.setStrokeWidth(5f);
        halo.setColor(0xCCFFFFFF);
        for (String row : TeethData.TEETH) {
            String[] p = row.split(";");
            int n = Integer.parseInt(p[0]);
            centers.put(n, new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2])});
            String[] pts = p[3].split(" ");
            float[] poly = new float[pts.length * 2];
            Path path = new Path();
            for (int i = 0; i < pts.length; i++) {
                String[] xy = pts[i].split(",");
                poly[i * 2] = Float.parseFloat(xy[0]);
                poly[i * 2 + 1] = Float.parseFloat(xy[1]);
                if (i == 0) path.moveTo(poly[0], poly[1]); else path.lineTo(poly[i * 2], poly[i * 2 + 1]);
            }
            path.close();
            polys.put(n, poly);
            paths.put(n, path);
        }
        bmp = BitmapFactory.decodeResource(getResources(), R.drawable.teeth_arch);
    }

    public void setReadOnly(boolean b) { readOnly = b; }
    public void setListener(Listener l) { listener = l; }

    public String getSelectedCsv() {
        StringBuilder sb = new StringBuilder();
        for (int t : selected) { if (sb.length() > 0) sb.append(","); sb.append(t); }
        return sb.toString();
    }

    public void setSelectedFromCsv(String csv) {
        selected.clear();
        if (csv != null && !csv.isEmpty())
            for (String s : csv.split(",")) {
                try { selected.add(Integer.parseInt(s.trim())); } catch (Exception ignored) { }
            }
        invalidate();
    }

    /** تحديد/إلغاء كل أسنان الفك العلوي (1x,2x) أو السفلي (3x,4x) */
    public void toggleJaw(boolean upper) {
        boolean all = true;
        for (int n : paths.keySet()) if (isUpper(n) == upper && !selected.contains(n)) all = false;
        for (int n : paths.keySet()) {
            if (isUpper(n) != upper) continue;
            if (all) selected.remove(n); else selected.add(n);
        }
        changed();
    }

    private static boolean isUpper(int n) { int q = n / 10; return q == 1 || q == 2; }

    public void clear() { selected.clear(); changed(); }

    private void changed() {
        invalidate();
        if (listener != null) listener.onChanged(getSelectedCsv());
    }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        if (w == 0) w = (int) (300 * getResources().getDisplayMetrics().density);
        setMeasuredDimension(w, (int) (w * TeethData.IMG_H / (float) TeethData.IMG_W));
    }

    @Override protected void onDraw(Canvas c) {
        scale = getWidth() / (float) TeethData.IMG_W;
        c.save();
        c.scale(scale, scale);
        if (bmp != null) c.drawBitmap(bmp, 0, 0, bmpPaint);
        for (Map.Entry<Integer, Path> e : paths.entrySet()) {
            boolean s = selected.contains(e.getKey());
            if (s) { c.drawPath(e.getValue(), fillSel); c.drawPath(e.getValue(), strokeSel); }
            float[] ctr = centers.get(e.getKey());
            String t = String.valueOf(e.getKey());
            if (!s) c.drawText(t, ctr[0], ctr[1] + 10f, halo);
            textPaint.setColor(s ? 0xFFFFFFFF : 0xFF1A1A2E);
            c.drawText(t, ctr[0], ctr[1] + 10f, textPaint);
        }
        c.restore();
    }

    private static boolean inside(float[] poly, float x, float y) {
        boolean in = false;
        int n = poly.length / 2;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float xi = poly[i * 2], yi = poly[i * 2 + 1], xj = poly[j * 2], yj = poly[j * 2 + 1];
            if (((yi > y) != (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) in = !in;
        }
        return in;
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (readOnly) return false;
        if (e.getAction() == MotionEvent.ACTION_DOWN) return true;
        if (e.getAction() == MotionEvent.ACTION_UP) {
            float x = e.getX() / scale, y = e.getY() / scale;
            int hit = -1;
            for (Map.Entry<Integer, float[]> p : polys.entrySet())
                if (inside(p.getValue(), x, y)) { hit = p.getKey(); break; }
            if (hit == -1) {
                float best = 45f;
                for (Map.Entry<Integer, float[]> p : centers.entrySet()) {
                    float d = (float) Math.hypot(x - p.getValue()[0], y - p.getValue()[1]);
                    if (d < best) { best = d; hit = p.getKey(); }
                }
            }
            if (hit != -1) {
                if (!selected.remove(hit)) selected.add(hit);
                changed();
            }
            performClick();
            return true;
        }
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }
}
