package com.dentallab.core;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.widget.ProgressBar;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.firestore.DocumentReference;
import java.util.ArrayList;
import java.util.List;

public class CaseDetailActivity extends AppCompatActivity {
    private CaseItem k;
    private boolean lab;
    private DocumentReference ref;
    private boolean uploading;

    /** المعمل: اختيار ملفات الشغل المنجز لإرجاعها للعيادة */
    private final ActivityResultLauncher<String[]> resultPicker = registerForActivityResult(
            new ActivityResultContracts.OpenMultipleDocuments(), list -> {
                if (list == null || list.isEmpty() || k == null) return;
                for (Uri u : list) {
                    try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch (Exception ignored) { }
                }
                uploadResults(new ArrayList<>(list), 0, new ArrayList<>());
            });

    private void setBusy(boolean on) {
        uploading = on;
        findViewById(R.id.progress).setVisibility(on ? View.VISIBLE : View.GONE);
        findViewById(R.id.tvProgress).setVisibility(on ? View.VISIBLE : View.GONE);
        findViewById(R.id.btnReturn).setEnabled(!on);
        findViewById(R.id.btnUpdate).setEnabled(!on);
    }

    private void uploadResults(final List<Uri> uris, final int i, final List<CaseFile> done) {
        TextView tv = findViewById(R.id.tvProgress);
        ProgressBar pb = findViewById(R.id.progress);
        if (i >= uris.size()) {
            List<CaseFile> all = new ArrayList<>();
            if (k.resultFiles != null) all.addAll(k.resultFiles);
            all.addAll(done);
            long now = System.currentTimeMillis();
            ref.update("resultFiles", all, "status", 6, "returnedAt", now, "updatedAt", now)
                    .addOnSuccessListener(x -> { setBusy(false); Ui.toast(this, R.string.toast_returned); load(); })
                    .addOnFailureListener(e -> { setBusy(false); Ui.toast(this, getString(R.string.err_upload, e.getLocalizedMessage())); });
            return;
        }
        setBusy(true);
        Uri u = uris.get(i);
        String name = FileUtil.displayName(this, u);
        tv.setText(getString(R.string.msg_uploading, i + 1, uris.size(), name));
        pb.setProgress(0);
        String path = "cases/" + k.clinicId + "/" + ref.getId() + "/result_" + System.currentTimeMillis() + "_" + FileUtil.safe(name);
        FileUtil.upload(u, path, name, FileUtil.sizeOf(this, u), pb::setProgress, (f, err) -> {
            if (err != null) { setBusy(false); Ui.toast(this, getString(R.string.err_upload, err.getLocalizedMessage())); return; }
            done.add(f);
            uploadResults(uris, i + 1, done);
        });
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_case_detail);
        Edge.apply(this);
        setTitle(R.string.title_case);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        lab = getIntent().getBooleanExtra("lab", false);
        String id = getIntent().getStringExtra("id");
        if (id == null) { finish(); return; }
        ref = Repo.db().collection("cases").document(id);
        load();
    }

    private void load() {
        ref.get().addOnSuccessListener(s -> {
            CaseItem fresh = s.toObject(CaseItem.class);
            if (fresh == null) { finish(); return; }
            k = fresh;
            render();
        }).addOnFailureListener(e -> finish());
    }

    private void render() {
        TextView title = findViewById(R.id.tvTitle);
        title.setText((k.urgent ? "\u26A1 " : "") + Ui.caseTitle(this, k, lab));
        TextView st = findViewById(R.id.tvStatus);
        st.setText(Ui.statusLabel(this, k.status));
        st.setBackground(Ui.pill(Ui.statusColor(k.status)));

        String patient = Ui.nz(k.patientRef).trim();
        StringBuilder info = new StringBuilder();
        if (lab) info.append("\uD83D\uDCDE ").append(Ui.nz(k.clinicPhone)).append('\n');
        info.append("\uD83D\uDD27 ").append(getString(R.string.lbl_work)).append(": ").append(Ui.workLabel(this, k.workType)).append('\n');
        if (!patient.isEmpty()) info.append("\uD83D\uDC64 ").append(getString(R.string.lbl_ref)).append(": ").append(patient).append('\n');
        info.append("\uD83C\uDFA8 ").append(getString(R.string.lbl_shade)).append(": ")
                .append(Ui.nz(k.shade).isEmpty() ? getString(R.string.unspecified) : k.shade).append('\n');
        info.append("\uD83D\uDCC5 ").append(getString(R.string.lbl_due)).append(": ").append(Ui.nz(k.dueDate)).append('\n');
        info.append("\uD83D\uDCB0 ").append(getString(R.string.lbl_price)).append(": ")
                .append(k.price > 0 ? Ui.money(k.price) : getString(R.string.price_none)).append('\n');
        info.append("\uD83D\uDCDD ").append(getString(R.string.lbl_notes)).append(": ").append(Ui.nz(k.notes));
        if (!Ui.nz(k.labNote).isEmpty()) info.append("\n\uD83D\uDCAC ").append(getString(R.string.lbl_lab_note)).append(": ").append(k.labNote);
        ((TextView) findViewById(R.id.tvInfo)).setText(info.toString());

        TeethChartView chart = findViewById(R.id.teeth);
        chart.setReadOnly(true);
        chart.setSelectedFromCsv(k.teeth);
        ((TextView) findViewById(R.id.tvTeeth)).setText(getString(R.string.teeth_selected, Ui.nz(k.teeth).replace(",", ", ")));

        LinearLayout box = findViewById(R.id.filesBox);
        box.removeAllViews();
        List<CaseFile> files = k.files;
        boolean has = files != null && !files.isEmpty();
        findViewById(R.id.tvFilesTitle).setVisibility(has ? View.VISIBLE : View.GONE);
        if (has) for (CaseFile f : files) {
            MaterialButton btn = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            btn.setText("\uD83D\uDCC4 " + f.name + "  (" + FileUtil.human(f.size) + ")");
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> FileUtil.openOrShare(this, f));
            box.addView(btn);
        }

        LinearLayout rbox = findViewById(R.id.resultBox);
        rbox.removeAllViews();
        boolean hasRes = k.resultFiles != null && !k.resultFiles.isEmpty();
        findViewById(R.id.tvResultTitle).setVisibility(hasRes ? View.VISIBLE : View.GONE);
        if (hasRes) for (CaseFile f : k.resultFiles) {
            MaterialButton btn = new MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
            btn.setText("\u2705 " + f.name + "  (" + FileUtil.human(f.size) + ")");
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> FileUtil.openOrShare(this, f));
            rbox.addView(btn);
        }

        View del = findViewById(R.id.btnDelete);
        if (lab) {
            findViewById(R.id.panelLab).setVisibility(View.VISIBLE);
            Spinner sp = findViewById(R.id.spStatus);
            sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Ui.statusLabels(this, 1)));
            sp.setSelection(Math.max(0, k.status - 1));
            EditText price = findViewById(R.id.etPrice);
            EditText note = findViewById(R.id.etLabNote);
            if (k.price > 0) price.setText(Ui.money(k.price));
            note.setText(Ui.nz(k.labNote));
            findViewById(R.id.btnUpdate).setOnClickListener(v ->
                ref.update("status", sp.getSelectedItemPosition() + 1,
                        "price", Ui.num(price.getText().toString()),
                        "labNote", note.getText().toString().trim(),
                        "updatedAt", System.currentTimeMillis())
                    .addOnSuccessListener(x -> { Ui.toast(this, R.string.toast_updated); load(); })
                    .addOnFailureListener(e -> Ui.toast(this, getString(R.string.err_auth, e.getLocalizedMessage()))));
            View receive = findViewById(R.id.btnReceive);
            receive.setVisibility(k.status == 1 ? View.VISIBLE : View.GONE);
            receive.setOnClickListener(v -> {
                long now = System.currentTimeMillis();
                ref.update("status", 2, "receivedAt", now, "updatedAt", now)
                        .addOnSuccessListener(x -> { Ui.toast(this, R.string.toast_received); load(); });
            });
            findViewById(R.id.btnReturn).setOnClickListener(v -> {
                if (!uploading) resultPicker.launch(new String[]{"*/*"});
            });
            findViewById(R.id.btnWa).setOnClickListener(v ->
                    Ui.whatsapp(this, k.clinicPhone, getString(R.string.msg_to_doctor, Ui.workLabel(this, k.workType))));
            findViewById(R.id.btnCall).setOnClickListener(v -> Ui.call(this, k.clinicPhone));
            del.setVisibility(View.VISIBLE);
        } else {
            // العيادة تستطيع إلغاء الحالة ما دامت جديدة فقط
            del.setVisibility(k.status == 1 ? View.VISIBLE : View.GONE);
        }
        del.setOnClickListener(v -> Ui.confirm(this, R.string.confirm_delete, () -> {
            FileUtil.deleteAll(k.files);
            FileUtil.deleteAll(k.resultFiles);
            ref.delete().addOnSuccessListener(x -> finish())
                    .addOnFailureListener(e -> Ui.toast(this, getString(R.string.err_auth, e.getLocalizedMessage())));
        }));
    }

    @Override public boolean onSupportNavigateUp() {
        if (uploading) { Ui.toast(this, R.string.msg_wait_upload); return true; }
        finish();
        return true;
    }
}
