package com.dentallab.core;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.List;

/** الشاشة الرئيسية المشتركة: شريط التبويبات + بوابة تسجيل الدخول + الإشعارات */
public abstract class BaseMainActivity extends AppCompatActivity implements Host {
    protected BottomNavigationView nav;
    protected ExtendedFloatingActionButton fab;
    private List<ListenerRegistration> regs;

    protected abstract int menuRes();
    protected abstract int firstItemId();
    protected abstract Fragment fragmentFor(int itemId);
    protected boolean fabVisibleFor(int itemId) { return false; }
    protected void onFabClick() { }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Repo.auth().getCurrentUser() == null || !Profile.exists(this)) {
            startActivity(new Intent(this, AuthActivity.class).putExtra("lab", isLab()));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        setTitle("\uD83E\uDDB7 " + Profile.name(this));
        nav = findViewById(R.id.nav);
        fab = findViewById(R.id.fabNew);
        nav.inflateMenu(menuRes());
        fab.setOnClickListener(v -> onFabClick());
        nav.setOnItemSelectedListener(i -> { show(i.getItemId()); return true; });
        if (b == null) nav.setSelectedItemId(firstItemId());

        Notifier.createChannel(this);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        Push.register(isLab());
        regs = Watcher.start(this, isLab());
    }

    protected void show(int itemId) {
        fab.setVisibility(fabVisibleFor(itemId) ? View.VISIBLE : View.GONE);
        getSupportFragmentManager().beginTransaction().replace(R.id.container, fragmentFor(itemId)).commitAllowingStateLoss();
    }

    @Override protected void onDestroy() {
        if (regs != null) for (ListenerRegistration r : regs) r.remove();
        super.onDestroy();
    }

    @Override public void openInventory() { }
}
