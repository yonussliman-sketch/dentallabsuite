package com.dentallab.core;
import android.content.Context;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import com.google.android.material.button.MaterialButton;

/** حقل رقم هاتف مع اختيار الدولة (علم + رمز الاتصال) */
public class PhoneField extends LinearLayout {
    private final MaterialButton btn;
    private final EditText et;
    private String iso;

    public PhoneField(Context c) { this(c, null); }

    public PhoneField(Context c, AttributeSet a) {
        super(c, a);
        setOrientation(HORIZONTAL);
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        btn = new MaterialButton(c, null, com.google.android.material.R.attr.materialButtonOutlinedStyle);
        btn.setAllCaps(false);
        et = new EditText(c);
        et.setInputType(InputType.TYPE_CLASS_PHONE);
        et.setHint(R.string.hint_phone);
        et.setTextDirection(View.TEXT_DIRECTION_LTR);
        et.setSingleLine(true);
        addView(btn, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        LayoutParams lp = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f);
        lp.setMarginStart((int) (8 * getResources().getDisplayMetrics().density));
        addView(et, lp);
        setCountry(Countries.defaultIso(c));
        btn.setOnClickListener(v -> CountryPicker.show(getContext(), iso, this::setCountry));
    }

    public void setCountry(String iso) {
        this.iso = iso;
        btn.setText(Countries.flag(iso) + "  +" + Countries.dial(iso) + "  \u25BE");
    }

    public void set(String iso, String national) {
        if (iso != null && !iso.isEmpty()) setCountry(iso);
        et.setText(national);
    }

    public String getIso() { return iso; }

    /** الرقم المحلي بدون رمز الدولة وبدون الصفر الأول */
    public String getNational() {
        String d = et.getText().toString().replaceAll("[^0-9]", "");
        while (d.startsWith("0")) d = d.substring(1);
        return d;
    }

    public String getE164() { return "+" + Countries.dial(iso) + getNational(); }
    public boolean isValid() { int n = getNational().length(); return n >= 5 && n <= 13; }
}
