package com.dentallab.core;

public class CaseFile {
    public String name, path;
    public long size;
    public CaseFile() {}
}
