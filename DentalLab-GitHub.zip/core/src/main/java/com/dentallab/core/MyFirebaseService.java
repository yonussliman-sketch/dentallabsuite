package com.dentallab.core;
import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        String uid = Repo.uid();
        if (!uid.isEmpty()) Repo.db().collection("users").document(uid).update("fcmToken", token);
    }
}
