package com.dentallab.core;
import com.google.firebase.firestore.DocumentId;

/** status: 0 بانتظار التأكيد، 1 مؤكد، 2 مرفوض */
public class Appointment {
    @DocumentId public String id;
    public String clinicId, clinicName, clinicPhone, patientRef, date, time;
    public int status;
    public long createdAt;
    public Appointment() {}
}
