package com.dentallab.core;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;

public class Repo {
    public static FirebaseFirestore db() { return FirebaseFirestore.getInstance(); }
    public static FirebaseAuth auth() { return FirebaseAuth.getInstance(); }
    public static FirebaseStorage storage() { return FirebaseStorage.getInstance(); }
    public static String uid() {
        FirebaseUser u = auth().getCurrentUser();
        return u == null ? "" : u.getUid();
    }
}
