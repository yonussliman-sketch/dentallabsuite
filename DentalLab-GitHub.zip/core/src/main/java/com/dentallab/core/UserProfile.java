package com.dentallab.core;
import com.google.firebase.firestore.DocumentId;

public class UserProfile {
    @DocumentId public String id;
    public String name, phone, iso, national, role, email, fcmToken;
    public UserProfile() {}
}
