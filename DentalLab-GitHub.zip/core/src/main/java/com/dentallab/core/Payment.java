package com.dentallab.core;
import com.google.firebase.firestore.DocumentId;

public class Payment {
    @DocumentId public String id;
    public String clinicId, note;
    public double amount;
    public long createdAt;
    public Payment() {}
}
