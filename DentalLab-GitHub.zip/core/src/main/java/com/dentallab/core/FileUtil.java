package com.dentallab.core;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.FileProvider;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.io.File;
import java.util.List;
import java.util.Locale;

/** رفع وتنزيل ملفات الحالات (STL / صور / PDF / أي صيغة) عبر Firebase Storage */
public class FileUtil {
    public interface Progress { void onProgress(int percent); }
    public interface Done { void onDone(CaseFile file, Exception error); }

    public static String displayName(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && q.getString(i) != null) return q.getString(i);
            }
        } catch (Exception ignored) { }
        return "file_" + System.currentTimeMillis();
    }

    public static long sizeOf(Context c, Uri u) {
        try (Cursor q = c.getContentResolver().query(u, null, null, null, null)) {
            if (q != null && q.moveToFirst()) {
                int i = q.getColumnIndex(OpenableColumns.SIZE);
                if (i >= 0) return q.getLong(i);
            }
        } catch (Exception ignored) { }
        return 0;
    }

    public static String safe(String name) {
        String s = name.replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 80 ? s.substring(s.length() - 80) : s;
    }

    public static String human(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return String.format(Locale.US, "%.1f KB", b / 1024.0);
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    public static void upload(Uri uri, String path, String name, long size, Progress p, Done d) {
        StorageReference ref = Repo.storage().getReference(path);
        UploadTask t = ref.putFile(uri);
        t.addOnProgressListener(s -> p.onProgress((int) (100.0 * s.getBytesTransferred() / Math.max(1, s.getTotalByteCount()))));
        t.addOnSuccessListener(s -> {
            CaseFile f = new CaseFile();
            f.name = name; f.path = path; f.size = size;
            d.onDone(f, null);
        }).addOnFailureListener(e -> d.onDone(null, e));
    }

    public static void deleteAll(List<CaseFile> files) {
        if (files == null) return;
        for (CaseFile f : files) Repo.storage().getReference(f.path).delete();
    }

    private static String mimeOf(String name) {
        int i = name.lastIndexOf('.');
        if (i > 0) {
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(i + 1).toLowerCase(Locale.US));
            if (m != null) return m;
        }
        return "application/octet-stream";
    }

    /** قائمة: فتح / مشاركة / حفظ في التنزيلات */
    public static void openOrShare(Context c, CaseFile f) {
        String[] items = {c.getString(R.string.file_open), c.getString(R.string.file_share), c.getString(R.string.file_save)};
        new AlertDialog.Builder(c).setTitle(f.name).setItems(items, (d, w) -> {
            if (w == 0) fetch(c, f, true);
            else if (w == 1) fetch(c, f, false);
            else saveToDownloads(c, f);
        }).setNegativeButton(R.string.btn_close, null).show();
    }

    private static void fetch(Context c, CaseFile f, boolean view) {
        AlertDialog dlg = Ui.busy(c, R.string.msg_downloading);
        File dir = new File(c.getCacheDir(), "dl");
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File o : old) o.delete();
        File dest = new File(dir, safe(f.name));
        Repo.storage().getReference(f.path).getFile(dest).addOnSuccessListener(t -> {
            dlg.dismiss();
            Uri u = FileProvider.getUriForFile(c, c.getPackageName() + ".files", dest);
            if (view) {
                Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(u, mimeOf(f.name))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { c.startActivity(i); return; } catch (Exception ignored) { }
            }
            Intent s = new Intent(Intent.ACTION_SEND).setType("application/octet-stream")
                    .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(Intent.createChooser(s, c.getString(R.string.share_title)));
        }).addOnFailureListener(e -> {
            dlg.dismiss();
            Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage()));
        });
    }

    private static void saveToDownloads(Context c, CaseFile f) {
        Repo.storage().getReference(f.path).getDownloadUrl().addOnSuccessListener(u -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(u);
                r.setTitle(f.name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, f.name.replaceAll("[\\\\/:*?\"<>|]", "_"));
                ((DownloadManager) c.getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Ui.toast(c, R.string.toast_download);
            } catch (Exception e) {
                Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage()));
            }
        }).addOnFailureListener(e -> Ui.toast(c, c.getString(R.string.err_download, e.getLocalizedMessage())));
    }
}
