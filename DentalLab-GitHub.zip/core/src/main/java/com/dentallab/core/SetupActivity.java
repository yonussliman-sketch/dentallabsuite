package com.dentallab.core;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

/** تعديل الملف الشخصي: الاسم + الدولة + رقم الهاتف (يراه المعمل ليتواصل مع الطبيب) */
public class SetupActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_setup);
        Edge.apply(this);
        setTitle(R.string.more_profile);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        final boolean lab = getIntent().getBooleanExtra("lab", false);
        ((TextView) findViewById(R.id.tvTitle)).setText(R.string.more_profile);
        findViewById(R.id.tvSub).setVisibility(android.view.View.GONE);
        final EditText name = findViewById(R.id.etName);
        final PhoneField phone = findViewById(R.id.phone);
        Button save = findViewById(R.id.btnSave);
        name.setHint(lab ? R.string.hint_name_lab : R.string.hint_name_clinic);
        save.setText(R.string.btn_save);
        name.setText(Profile.name(this));
        phone.set(Profile.iso(this), Profile.national(this));
        save.setOnClickListener(v -> {
            final String n = name.getText().toString().trim();
            if (n.isEmpty()) { Ui.toast(this, R.string.err_name); return; }
            if (!phone.isValid()) { Ui.toast(this, R.string.err_phone); return; }
            Map<String, Object> u = new HashMap<>();
            u.put("name", n); u.put("phone", phone.getE164()); u.put("iso", phone.getIso()); u.put("national", phone.getNational());
            save.setEnabled(false);
            Repo.db().collection("users").document(Repo.uid()).update(u).addOnSuccessListener(x -> {
                Profile.save(this, n, phone.getIso(), phone.getNational(), phone.getE164(), lab ? "lab" : "clinic");
                Ui.toast(this, R.string.toast_updated);
                finish();
            }).addOnFailureListener(e -> {
                save.setEnabled(true);
                Ui.toast(this, getString(R.string.err_auth, e.getLocalizedMessage()));
            });
        });
    }

    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}
