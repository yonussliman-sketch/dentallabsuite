package com.dentallab.core;
import android.app.Activity;
import android.view.View;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/** يضبط الهوامش في الشاشات التي بلا شريط سفلي (Edge-to-Edge إلزامي في Android 15+) */
public class Edge {
    public static void apply(Activity a) {
        View root = a.findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets b = insets.getInsets(WindowInsetsCompat.Type.systemBars()
                    | WindowInsetsCompat.Type.displayCutout() | WindowInsetsCompat.Type.ime());
            v.setPadding(b.left, 0, b.right, b.bottom);
            return insets;
        });
    }
}
