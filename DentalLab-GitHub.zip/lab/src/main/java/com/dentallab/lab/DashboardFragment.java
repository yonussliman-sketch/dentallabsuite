package com.dentallab.lab;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.List;

/** لوحة المعلومات اللحظية */
public class DashboardFragment extends Fragment {
    private final List<CaseItem> cases = new ArrayList<>();
    private final List<Appointment> appts = new ArrayList<>();
    private final List<Payment> pays = new ArrayList<>();
    private final List<ListenerRegistration> regs = new ArrayList<>();
    private int clinics = 0;
    private ListView list;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        v.findViewById(R.id.empty).setVisibility(View.GONE);
        TextView h = v.findViewById(R.id.header);
        h.setVisibility(View.VISIBLE);
        h.setText(R.string.dash_title);
        h.setTextSize(18);
        list = v.findViewById(R.id.list);
        regs.add(Repo.db().collection("cases").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            cases.clear(); cases.addAll(snap.toObjects(CaseItem.class)); render();
        }));
        regs.add(Repo.db().collection("appointments").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            appts.clear(); appts.addAll(snap.toObjects(Appointment.class)); render();
        }));
        regs.add(Repo.db().collection("payments").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            pays.clear(); pays.addAll(snap.toObjects(Payment.class)); render();
        }));
        regs.add(Repo.db().collection("users").whereEqualTo("role", "clinic").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            clinics = snap.size(); render();
        }));
        return v;
    }

    private void render() {
        if (!isAdded()) return;
        int[] cnt = new int[7];
        int urgent = 0, pending = 0;
        double due = 0, paid = 0;
        for (CaseItem k : cases) {
            cnt[Math.max(0, Math.min(6, k.status))]++;
            if (k.urgent && k.status >= 1 && k.status < 6) urgent++;
            due += k.price;
        }
        for (Payment p : pays) paid += p.amount;
        for (Appointment a : appts) if (a.status == 0) pending++;

        List<CardAdapter.Row> rows = new ArrayList<>();
        rows.add(new CardAdapter.Row("\uD83C\uDD95 " + getString(R.string.dash_to_receive), "", String.valueOf(cnt[1]), Ui.statusColor(1)));
        rows.add(new CardAdapter.Row("\uD83D\uDCE5 " + getString(R.string.st_received), "", String.valueOf(cnt[2]), Ui.statusColor(2)));
        rows.add(new CardAdapter.Row("\uD83D\uDEE0 " + getString(R.string.st_progress), "", String.valueOf(cnt[3]), Ui.statusColor(3)));
        rows.add(new CardAdapter.Row("\uD83D\uDD0D " + getString(R.string.st_qc), "", String.valueOf(cnt[4]), Ui.statusColor(4)));
        rows.add(new CardAdapter.Row("\u2705 " + getString(R.string.st_ready), "", String.valueOf(cnt[5]), Ui.statusColor(5)));
        rows.add(new CardAdapter.Row("\uD83D\uDCE4 " + getString(R.string.st_delivered), "", String.valueOf(cnt[6]), Ui.statusColor(6)));
        rows.add(new CardAdapter.Row("\u26A1 " + getString(R.string.dash_urgent), "", String.valueOf(urgent), 0xFFC62828));
        rows.add(new CardAdapter.Row("\uD83D\uDCC5 " + getString(R.string.dash_appts), "", String.valueOf(pending), Ui.apptColor(0)));
        rows.add(new CardAdapter.Row("\uD83C\uDFE5 " + getString(R.string.dash_clinics), "", String.valueOf(clinics), 0xFF546E7A));
        rows.add(new CardAdapter.Row("\uD83D\uDCB0 " + getString(R.string.dash_balance),
                getString(R.string.acc_short, Ui.money(due), Ui.money(paid)), Ui.money(due - paid),
                due - paid > 0 ? 0xFFC62828 : 0xFF2E7D32));
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    @Override public void onDestroyView() {
        for (ListenerRegistration r : regs) r.remove();
        regs.clear();
        super.onDestroyView();
    }
}
