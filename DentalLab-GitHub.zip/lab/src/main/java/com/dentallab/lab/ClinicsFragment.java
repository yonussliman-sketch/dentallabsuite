package com.dentallab.lab;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.dentallab.core.*;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** الأطباء/العيادات: رصيد كل طبيب. اضغط لتسجيل دفعة أو التواصل */
public class ClinicsFragment extends Fragment {
    private final List<UserProfile> clinics = new ArrayList<>();
    private final List<CaseItem> cases = new ArrayList<>();
    private final List<Payment> pays = new ArrayList<>();
    private final List<ListenerRegistration> regs = new ArrayList<>();
    private ListView list;
    private TextView header;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.fragment_list, c, false);
        v.findViewById(R.id.fab).setVisibility(View.GONE);
        list = v.findViewById(R.id.list);
        list.setEmptyView(v.findViewById(R.id.empty));
        header = v.findViewById(R.id.header);
        header.setVisibility(View.VISIBLE);
        regs.add(Repo.db().collection("users").whereEqualTo("role", "clinic").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            clinics.clear(); clinics.addAll(snap.toObjects(UserProfile.class)); render();
        }));
        regs.add(Repo.db().collection("cases").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            cases.clear(); cases.addAll(snap.toObjects(CaseItem.class)); render();
        }));
        regs.add(Repo.db().collection("payments").addSnapshotListener((snap, e) -> {
            if (snap == null || !isAdded()) return;
            pays.clear(); pays.addAll(snap.toObjects(Payment.class)); render();
        }));
        list.setOnItemClickListener((p, view, pos, id) -> options(clinics.get(pos)));
        return v;
    }

    private void render() {
        if (!isAdded()) return;
        Map<String, double[]> m = new HashMap<>();
        for (UserProfile u : clinics) m.put(u.id, new double[2]);
        for (CaseItem k : cases) { double[] a = m.get(k.clinicId); if (a != null) a[0] += k.price; }
        for (Payment p : pays) { double[] a = m.get(p.clinicId); if (a != null) a[1] += p.amount; }
        double due = 0, paid = 0;
        List<CardAdapter.Row> rows = new ArrayList<>();
        for (UserProfile u : clinics) {
            double[] a = m.get(u.id);
            due += a[0]; paid += a[1];
            double rem = a[0] - a[1];
            rows.add(new CardAdapter.Row("\uD83D\uDC68\u200D\u2695\uFE0F " + Ui.nz(u.name),
                    getString(R.string.acc_short, Ui.money(a[0]), Ui.money(a[1])) + "\n\uD83D\uDCDE " + Ui.nz(u.phone),
                    Ui.money(rem), rem > 0 ? 0xFFC62828 : 0xFF2E7D32));
        }
        header.setText(getString(R.string.acc_summary, Ui.money(due), Ui.money(paid), Ui.money(due - paid)));
        list.setAdapter(new CardAdapter(requireContext(), rows));
    }

    private void options(UserProfile u) {
        String[] items = {getString(R.string.opt_pay), getString(R.string.btn_wa_doctor), getString(R.string.btn_call_doctor)};
        new AlertDialog.Builder(requireContext()).setTitle(Ui.nz(u.name)).setItems(items, (d, w) -> {
            if (w == 0) addPayment(u);
            else if (w == 1) Ui.whatsapp(requireContext(), u.phone, getString(R.string.msg_to_doctor_generic));
            else Ui.call(requireContext(), u.phone);
        }).show();
    }

    private void addPayment(UserProfile u) {
        Ui.form(requireContext(), R.string.opt_pay, new int[]{R.string.hint_amount, R.string.hint_note}, f -> {
            double amount = Ui.num(f[0]);
            if (amount <= 0) return;
            Payment p = new Payment();
            p.clinicId = u.id; p.amount = amount; p.note = f[1]; p.createdAt = System.currentTimeMillis();
            Repo.db().collection("payments").add(p);
        });
    }

    @Override public void onDestroyView() {
        for (ListenerRegistration r : regs) r.remove();
        regs.clear();
        super.onDestroyView();
    }
}
