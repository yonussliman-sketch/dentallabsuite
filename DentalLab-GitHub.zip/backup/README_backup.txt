النسخ الاحتياطي لبيانات المعمل — ثلاث طبقات:

1) تلقائي من Google (يومي + أسبوعي + استعادة لحظية): شغّل مرة واحدة
      ./backup/enable_backups.sh PROJECT_ID        (ويندوز: backup\enable_backups.bat PROJECT_ID)
   أو من الموقع: Firebase Console ← Firestore Database ← تبويب Disaster recovery ← Schedule backups.
   (يتطلب خطة Blaze، ولا يمكن تفعيله من داخل التطبيق لأنه إعداد على مستوى المشروع.)

2) نسخة يدوية بيدك: تطبيق المعمل ← الإعدادات ← "تصدير تقرير" ← PDF أو Excel (حالات + حسابات + دفعات).
   احفظه على Google Drive أو أرسله لنفسك أسبوعياً.

3) ملفات الحالات (STL وغيرها): محفوظة في Firebase Storage؛ فعّل فيها حذفاً مؤجلاً (Soft delete) من Google Cloud Console
   ← Cloud Storage ← اختر الـ bucket ← Protection، لاسترجاع أي ملف محذوف بالخطأ.
