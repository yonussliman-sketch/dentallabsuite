#!/usr/bin/env bash
# تفعيل النسخ الاحتياطية التلقائية لقاعدة بيانات Firestore (يتطلب خطة Blaze + تثبيت gcloud)
# الاستخدام:  ./enable_backups.sh PROJECT_ID
set -e
P="${1:?اكتب معرّف المشروع: ./enable_backups.sh PROJECT_ID}"
gcloud config set project "$P"
gcloud services enable firestore.googleapis.com

# 1) الاستعادة لأي لحظة خلال آخر 7 أيام (Point-in-time recovery)
gcloud firestore databases update --database="(default)" --enable-pitr || echo "تعذّر تفعيل PITR (قد يكون مفعلاً)"

# 2) نسخة يومية تُحفظ 7 أيام + نسخة أسبوعية (الأحد) تُحفظ 14 أسبوعاً
gcloud firestore backups schedules create --database="(default)" --recurrence=daily --retention=7d
gcloud firestore backups schedules create --database="(default)" --recurrence=weekly --day-of-week=SUN --retention=14w

gcloud firestore backups schedules list --database="(default)"
echo "تم. لاستعادة نسخة:  gcloud firestore backups list   ثم   gcloud firestore databases restore --source-backup=BACKUP_NAME --destination-database=restored-db"
