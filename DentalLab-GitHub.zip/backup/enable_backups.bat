@echo off
REM تفعيل النسخ الاحتياطية التلقائية لـ Firestore (يتطلب gcloud + خطة Blaze)
REM الاستخدام:  enable_backups.bat PROJECT_ID
if "%1"=="" (echo اكتب معرّف المشروع: enable_backups.bat PROJECT_ID & exit /b 1)
call gcloud config set project %1
call gcloud services enable firestore.googleapis.com
call gcloud firestore databases update --database="(default)" --enable-pitr
call gcloud firestore backups schedules create --database="(default)" --recurrence=daily --retention=7d
call gcloud firestore backups schedules create --database="(default)" --recurrence=weekly --day-of-week=SUN --retention=14w
call gcloud firestore backups schedules list --database="(default)"
